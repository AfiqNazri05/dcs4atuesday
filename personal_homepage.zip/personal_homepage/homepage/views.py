from django.shortcuts import render
from homepage.models import Programme, Mentor, Student

# Create your views here.

def index(request):
    myprogramme = Programme.objects.all().values()
    mymentor = Mentor.objects.all().values()
    context = {
        'studentname' : "Afiq",
        'myprogramme' : myprogramme,
        'mymentor' : mymentor
    }
    return render (request,"index.html", context)

def newmentor(request) :
    displaydata = Mentor.objects.all().values()
    if request.method == "POST" :
        menid1 = request.POST['mentorid1']
        menname1 = request.POST['mentorname1']
        menemail1 = request.POST['menemail1']
        data = Mentor(mentorid = menid1, mentorname = menname1, mentoremail = menemail1)
        data.save()

        context = {
            'displaydata' : displaydata,
            'message' : 'NEW MENTOR HAS BEEN SAVE'
        }

        return render (request,"index.html", context)
    else :
        dict = {
            'message' : '',
            'displaydata' : displaydata,
        }

        return render (request,"index.html", dict)
    
def newstudent (request) :
    studmentor1 = Student.objects.all().values()
    mymentor = Mentor.objects.all().values()
    if request.method == "POST" :
        studentid1 = request.POST["studentid"]
        studentname1 = request.POST["studentname"]
        studentemail1 = request.POST["studentemail"]
        studentage1 = request.POST["studentage"]
        mentorid1 = request.POST["selectmentorid"]
        mentornew = Mentor.objects.get(mentorid = mentorid1)
        data = Student(studentid = studentid1, studentname = studentname1, studentemail = studentemail1, studentage = studentage1, studentmentorid = mentornew)
        data.save()

        context = {
            'studentmentorid' : studmentor1,
            'mymentor' : mymentor,
            'message' : 'NEW STUDENT HAS BEEN SAVE'
        } 

        return render (request,"index.html", context)
    else :
        dict = {
            'studentmentor' : studmentor1,
            'mymentor' : mymentor,
            'message' : '',
        }

        return render (request,"index.html", dict)


    
